function main(arr) {
	// Your code begins here;
}

module.exports = { main };
