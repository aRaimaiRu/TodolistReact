function main() {
	// Your code begins here;
}

module.exports = { main };
