function main(str, str2) {
	// Your code begins here;
}

module.exports = { main };