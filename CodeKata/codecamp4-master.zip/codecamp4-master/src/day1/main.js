function main(str) {
	// Your code begins here;
}

module.exports = { main };
